/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _CRYPTO_HMAC_H
#define _CRYPTO_HMAC_H

#define HMAC_IPAD_VALUE 0x36
#define HMAC_OPAD_VALUE 0x5c

#endif /* _CRYPTO_HMAC_H */
